package exam1;

/**
 * Created by pedrotgn on 05/10/16.
 */
public class Room {
    private int cost;

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public Room(int cost) {

        this.cost = cost;
    }
}
