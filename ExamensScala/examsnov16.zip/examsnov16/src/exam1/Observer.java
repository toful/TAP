package exam1;

/**
 * Created by pedrotgn on 05/10/16.
 */
public interface Observer {
    public void newHotel(Hotel h);
}
