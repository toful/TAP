package course;

/**
 * Created by pedro on 27/09/15.
 */
public class Student extends Person {
    public Student(String code,String name, int age) {
        super(code,name, age);
    }
}
