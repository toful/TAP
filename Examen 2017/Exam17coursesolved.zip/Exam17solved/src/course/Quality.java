package course;

/**
 * Created by pedro on 27/09/15.
 */
public enum Quality {DISASTER,BAD, NORMAL, GOOD};
